clear
set more 1
set matsize 2000

capture log using "estimation main tables.log", replace
use estdata
*dropping top and bottom one percentiles based on dexports out of estimation but keep in sample for heckman
*drop if clean1==1
replace dexports=. if clean1==1

gen crisis=1 if year==1991|year==1993|year==1998
replace crisis=0 if crisis==.
gen crisis_lagdvalue=crisis*lagdvalue_ref


egen ind4y=group(ind year)
tab ind4y, gen(idum)
tab year, gen(yr)
tab dbjbankcode_ref, gen(dbdum)




**************************************
*ESTIMATION
***************************************

*table 3
*******************
*col 1 - year effects
reg dexports lagdvalue_ref yr*, cluster(dbjbankcode_ref) robust

*col 2 - industry-year effects
areg dexports lagdvalue_ref, absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 3 - industry-year effects & bank fe
areg dexports lagdvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust


*col 4 - lag2 mtb and contemporaneous mtb
areg dexports dvalue_ref lagdvalue_ref lag2dvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 5 - sample of firms that do not export
*do nonexporters for this result

*col 6 - domsales, keep sample such that firm is always exporting
*note clean2 is top and bottom 1 percentiles of ddomsales
areg ddomsales lagdvalue_ref dbdum* if clean1~=1& clean2~=1 & dexports~=., absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 7 - ratio of d(export to domsales)
areg dexports_domsales lagdvalue_ref dbdum* if clean1~=1& clean2~=1, absorb(ind4y) cluster(dbjbankcode_ref) robust 



*table 4
*******************************
*col 1 - with lagged dependent variable so use Arrellano-Bond
gen firmcode=id
replace firmcode=tsecode if firmcode==.
tsset firmcode year
xtabond dexports lagdvalue_ref dbdum* idum* if year<2000, vce(robust)


*col 2 - lagged performance measures
areg dexports lagdvalue_ref lagdtotassets lagdprofits dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust


*col 3 - pre-Asian crisis as before
areg dexports lagdvalue_ref dbdum* if year<1997, absorb(ind4y) cluster(dbjbankcode_ref) robust 

*col 4 - controlling for export destination gdp growth
*we only have by destination exports for 1998 and 1999 so lilmit sample to begin in 1997
areg dexports lagdvalue_ref wgdpgrowth lagwgdpgrowth dbdum* if year>=1997, absorb(ind4y) cluster(dbjbankcode_ref) robust

*estimate without destination gdp and keep sample size same for comparison
areg dexports lagdvalue_ref dbdum* if year>=1997 & lagwgdpgrowth~=., absorb(ind4y) cluster (dbjbankcode_ref) robust


*col 5 an col 6- firm share prices
*IV estimation, see below


*********************************************
*table 5  - robustness measurement

*neeed different bank dummies
tab dbjbankcode_ll, gen(dbll)
tab dbjbankcode_refall, gen(dba)

*col 1 - show that using alternative match of banks to firms not affect results based on largest loan provider out of city banks
areg dexports lagdvalue_ll dbll*, absorb(ind4y) cluster(dbjbankcode_ll) robust

*col 2 - using all reference banks
areg dexports lagdvalue_refall dba*, absorb(ind4y) cluster(dbjbankcode_refall) robust

*col 3 - average of previous 3 months
areg dexports d2avalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust


*col 4 - accounting period - only keep March
est store reg14
areg dexports lagdvalue_ref dbdum* if month==3 , absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 5 - alternative bank health measure - capital ratio
areg dexports lagdrbc dbdum* , absorb(ind4y) cluster(dbjbankcode_ref) robust


********************************************
*table 6
*col 1
areg dexports lagdvalue_ref crisis_lagdvalue dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust


*col 2
*recent period - run separate do file

*nonlinearities
*check for asymmetric effects
gen mtb=lagdvalue_ref
replace mtb=. if dexports==.
gen up=mtb>0 & mtb~=.
gen down=mtb<0 & mtb~=.



egen q1=pctile(mtb), p(25)
egen q4=pctile(mtb), p(75)

/*based on bank data with all months
gen q1= -.3148115 
gen q4=.1306879 

*based on bank data with only March
gen q1= -.228861  
gen q4=.0793409 */

gen bottom=q1>lagdvalue_ref & lagdvalue_ref~=.
gen top=q4<lagdvalue_ref
sum q1 q4
tab bottom if dexports~=.
tab top if dexports~=.

gen up_lagdvalue_ref=up*lagdvalue_ref
gen down_lagdvalue_ref=down*lagdvalue_ref
gen bottom_lagdvalue_ref=bottom*lagdvalue_ref
gen top_lagdvalue_ref=top*lagdvalue_ref


*col 3
areg dexports lagdvalue_ref down_lagdvalue_ref dbdum* , absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 4
areg dexports lagdvalue_ref top_lagdvalue_ref bottom_lagdvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust
test bottom_lagdvalue_ref+lagdvalue_ref=top_lagdvalue_ref+lagdvalue_ref


*col 5 - air interaction
gen air_lagdvalue_ref=air*lagdvalue_ref
areg dexports lagdvalue_ref air_lagdvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust
lincom lagdvalue_ref+air_lagdvalue_ref

*col 6 - foreign affiliate interaction
*forshare
gen dumforeign=1 if foreign_assets>0 & foreign_assets~=.
replace dumforeign=0 if foreign_assets==.
gen dumforeign_lagdvalue_ref=dumforeign*lagdvalue_ref

*only do 1997-1999 since data on foreign assets only begins in 1998
areg dexports lagdvalue_ref dumforeign_lagdvalue_ref dumforeign dbdum* if year>=1997, absorb(ind4y) cluster(dbjbankcode_ref) robust
lincom lagdvalue_ref+dumforeign_lagdvalue_ref



********************************************
*table 7
*no bank switchers
*full sample
*col 1 - show that taking out bank switchers does not affect results (little stronger). We leave in mergers
tab totswitch
areg dexports lagdvalue_ref dbdum* if totswitch==0, absorb(ind4y) cluster(dbjbankcode_ref) robust

*col 2 - percentage change in market to book value
*full sample
areg dexports lagpdvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust

save temp, replace

*col 4
*tobit
xtset ind
xttobit pcexports lagdvalue_ref dbdum* yr* if clean1~=1, ll(-1) 

xttobit change_exports_totsales lagdvalue_ref dbdum* yr* if clean1~=1, ll(-1) 

*do Heckman and IV below
********************************************************************
*subsample
******************
*col3 - heckman
*tab ind4y, gen(i4)
*set matsize 3000
*col 3
heckman dexports lagdvalue_ref idum* dbdum*, select(lagrelative_vaw lagdvalue_ref yr* dbdum*) twostep 

gen sample=dexports~=.
probit sample lagrelative_vaw lagdvalue_ref yr* dbdum* 
predict tmp
g double imr1 = normalden(tmp)/normal(tmp)
areg dexports lagdvalue_ref dbdum* imr1, absorb(ind4y) cluster(dbjbankcode_ref) robust


drop _all
use temp

***********************************
*do IV here
************************************************************************
*need to demean everything first in order to run the iv with all the dummies
**********************************************************************************
*col 5 (Table 4) - lagged performance measures - firm share prices
areg lagdvalue_ref lagdav_shprice if dexports~=., absorb(ind4y) cluster(dbjbankcode_ref) robust 
predict resid, resid

save temp, replace

*local exo3 = "lt"
local end3 = "lagdvalue_ref"
local iv3  = "resid"


*local dm_exo3 = "dm_lt"
local dm_end3 = "dm_lagdvalue_ref"
local dm_iv3  = "dm_resid"

tsset,clear

forval v = 3/3 {

noisily xtivreg dexports (`end`v'' = `iv`v''), i(ind4y) fe
keep if e(sample)
qui foreach b of varlist dexports `end`v'' `iv`v'' dbdum* {
bys ind4y: egen tmp_`b' = mean(`b')
g dm_`b' = `b' - tmp_`b'
drop tmp_`b'
}

*col 5
ivreg2 dm_dexports (`dm_end`v'' = `dm_iv`v'')  dm_dbdum*, cluster(dbjbankcode_ref) first

ivreg2 dm_dexports (`dm_end`v'' = `dm_iv`v'')  dm_dbdum*, cluster(dbjbankcode_ref) first partial(dm_dbdum*)

est store iv_dexports
}


drop _all
use temp

****************
*local exo3 = "lt"
local end3 = "lagdvalue_ref"
local iv3  = "resid"


*local dm_exo3 = "dm_lt"
local dm_end3 = "dm_lagdvalue_ref"
local dm_iv3  = "dm_resid"

tsset,clear

forval v = 3/3 {

noisily xtivreg dexports_domsales (`end`v'' = `iv`v''), i(ind4y) fe
keep if e(sample)
qui foreach b of varlist dexports_domsales `end`v'' `iv`v'' dbdum* {
bys ind4y: egen tmp_`b' = mean(`b')
g dm_`b' = `b' - tmp_`b'
drop tmp_`b'
}

*col 6
ivreg2 dm_dexports_domsales (`dm_end`v'' = `dm_iv`v'')  dm_dbdum*, cluster(dbjbankcode_ref) first

ivreg2 dm_dexports_domsales (`dm_end`v'' = `dm_iv`v'')  dm_dbdum*, cluster(dbjbankcode_ref) first partial(dm_dbdum*)

est store iv_dexports_domsales
}


log close

