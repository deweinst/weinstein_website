clear
set more 1

use ../data/bank_balance_sheet_data_1985-2010
*note that all variables are in millions of yen
keep if month==3
*assign dbjbankcodes
gen dbjbankcode=.
*dbjname is DKB
replace dbjbankcode=80001 if fi_name=="MIZUHO BANK"
replace dbjbankcode=80002 if fi_name=="SAKURA BANK"
*dbjname is Fuji Bank
replace dbjbankcode=80003 if fi_name=="MIZUHO CORPORATE BANK"
*dbjname is BTM
replace dbjbankcode=80005 if fi_name=="BANK OF TOKYOMITSUBISHI UFJ" 
replace dbjbankcode=80006 if fi_name=="ASAHI BANK"
*dbjname is Sanwa
replace dbjbankcode=80008 if fi_name=="UFJ BANK"
*dbjname is Sumitomo
replace dbjbankcode=80009 if fi_name=="SUMITOMO MITSUI BANKING"
*dbjname is Daiwa bank
replace dbjbankcode=80010 if fi_name=="RESONA BANK"
replace dbjbankcode=80011 if fi_name=="TOKAI BANK"
replace dbjbankcode=80012 if fi_name=="HOKKAIDO TAKUSHOKU BANK"
replace dbjbankcode=80014 if fi_name=="TAIYO KOBE BANK"
replace dbjbankcode=80015 if fi_name=="BANK OF TOKYO"
replace dbjbankcode=80032 if fi_name=="SAITAMA BANK"
replace dbjbankcode=80396 if fi_name=="INDUSTRIAL BANK OF JAPAN"
*dbjname is LTCB
replace dbjbankcode=80397 if fi_name=="SHINSEI BANK"

drop if dbjbankcode==.
drop if year>1999
order dbjbankcode year


*rename variables
rename finfsta_k11150 realestate
rename finfsta_k11152 guarantee
rename finfsta_k11136 fin
rename finfsta_k11154 totloans

rename finfsta_b11028 allbills 
rename finfsta_b11061 bills
rename finfsta_b11053 totloans_a

label var bills "foreign bills bought"
rename finfsta_k11137 realestate_i
rename finfsta_k11143 totloans_i


*ratios
gen g_loans=guarantee/totloans
gen re_loans=realestate/totloans
gen fin_loans=fin/totloans_i
gen re_loans_i=realestate_i/totloans_i

gen lnbills=ln(bills)
gen billsratio=bills/totloans_a
gen lnbillsratio=ln(billsratio)
gen lntotloans_a=ln(totloans_a)
gen tight_ratio=allbills/totloans_a
gen lntight_ratio=ln(tight_ratio)

*lagged ratio
tsset dbjbankcode year
gen lagg_loans=l.g_loans
gen lagfin_loans=l.fin_loans
gen lagre_loans=l.re_loans
gen lagre_loans_i=l.re_loans_i

*differences
gen dre_loans=re_loans-l.re_loans
gen lagdre_loans=l.dre_loans
gen dbillsratio=billsratio-l.billsratio
gen lagdbillsratio=l.dbillsratio
gen dlnbillsratio=ln(billsratio)-ln(l.billsratio)
gen lagdlnbillsratio=l.dlnbillsratio
gen dtight_ratio=tight_ratio-l.tight_ratio
gen dlntight_ratio=ln(tight_ratio)-ln(l.tight_ratio)
gen dbills=ln(bills)-ln(l.bills)
gen dtotloans=lntotloans_a-l.lntotloans_a
gen lagdtotloans=l.dtotloans
gen d2bills=ln(bills)-ln(l2.bills)
sort dbjbankcode year
save bankbalancesheet, replace
save temp, replace


*take care of bank mergers here
*************************************
*bank 80015 (Bank of Tokyo) becomes 80005 (BOTM) after 1995 (but we have up to 96 data for Bank of Tokyo so make change in following year)
*bank 80014 (Tiayo-Kobe) merges with Mitusu to become Sakura (80002) in 1990
*bank 80032 (Saitama) merges to become Asahi in 1991

keep if dbjbankcode==80005|dbjbankcode==80002|dbjbankcode==80006
drop if dbjbankcode==80005 & year<=1996
drop if dbjbankcode==80002 & year<=1990
drop if dbjbankcode==80006 & year<=1991
replace dbjbankcode=80015 if dbjbankcode==80005 
replace dbjbankcode=80014 if dbjbankcode==80002
replace dbjbankcode=80032 if dbjbankcode==80006
save tempbanks, replace

use temp
append using tempbanks
sort dbjbankcode year month
save collateral_data, replace
erase tempbanks.dta


***************************************
use bankperformance

keep year month dbjbankcode dvalue lagdvalue  market_to_book lvalue  laglvalue mv
keep if month==3

save dbjbankperformance, replace

tsset dbjbankcode year
gen d2value=lvalue-l2.lvalue

sort dbjbankcode year month
merge dbjbankcode year month using collateral_data
tab _merge
drop _merge


drop if year<1986

egen p1=pctile(dbills), p(1)
egen p99=pctile(dbills), p(99)
gen clean=1 if dbills<=p1
replace clean=1 if dbills>=p99 & dbills~=p99
replace clean=0 if clean==.

egen q1=pctile(dlnbillsratio), p(1)
egen q99=pctile(dlnbillsratio), p(99)
gen clean1=1 if dlnbillsratio<=p1
replace clean1=1 if dlnbillsratio>=p99 & dlnbillsratio~=p99
replace clean1=0 if clean1==.
drop if clean==1
drop if clean1==1
tsset dbjbankcode year
sort dbjbankcode year month
save foreignbillsdata, replace



capture log using "trade finance loans.log", replace
tab year, gen(yr)
*table 2 - col 1
areg lntotloans laglvalue yr*, absorb(dbjbankcode) robust

*table 2 - col 2
areg lnbills laglvalue yr*, absorb(dbjbankcode) robust

*table 2 - col 3
*second show that trade finance falls by more than other loans
areg lnbillsratio laglvalue yr*, absorb(dbjbankcode) robust

log close
