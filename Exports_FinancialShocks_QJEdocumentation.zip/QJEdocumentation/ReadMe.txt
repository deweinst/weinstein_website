
*****************
*DATA sources
*****************

We provide the data that we are allowed to provide and include sources of where the rest of the data can be purchased.

1. Firm-level data
a. DBJ data - 1986 to 1999 can be ordered from  http://www.jeri.co.jp/data/
b. consolidated data - 2003 to 2010 can be ordered from http://finquest.nikkeidb.or.jp/ver2/online/index_en.htm 


2. Bank performance data can be ordered from Nikkei http://finquest.nikkeidb.or.jp/ver2/online/index_en.htm


3. Bank balance sheet data used in bank-level regressions can be obtained from http://finquest.nikkeidb.or.jp/ver2/online/index_en.htm 

4. For the capital ratio data used in robustness checks see: Peek, Joe, and Eric S. Rosengren 2005. "Unnatural Selection: Perverse Incentives and the Misallocation of Credit in Japan." American Economic Review 95(4): 1144-66.


5. Reference banks
a. listreferencecitybanks.dta 
- this file contains the first listed city reference bank for each tsecode by year, which were manually entered from Japan Company Handbook, various issues

b. listreferenceallbanks.dta
- this file contains the first listed reference bank (even if not a city bank) for each tsecode by year, which were manually entered from  Japan Company Handbook, various issues


6. sea1995.dta
This contains the share of trade that is exported by sea by industry for 1995. The source of this data is Ministry of Finance http://www.customs.go.jp/toukei/info/index_e.htm


7. gdpgrowth.dta
- this contains gdp growth rates grouped into regions as reported in the firm-destination specific variable. These comprise four groupings: North America, EU, Asia, and Middle East. To construct regional growth rates, we use Japan's export shares as weights obtained from the World Banks World Integrated Trade Solution (WITS) http://wits.worldbank.org/wits/. Country level GDP numbers are from IMF World Economic Outlook. Individual firm-level data, available only in 1998 and 1999, weights were used to construct firm-level weighted GDPs used in a robustness test, which can be found at http://www.jeri.co.jp/data/. 


**********************************
*Data construction program files
*************************************
exporters.do
-this file constructs the firm level data used in the main estimations.

nonexporters.do
-this file constructs the data and produces columns 


**************************
*Regression tables
*****************************
trade finance loans.do
-this file produces columns 1 to 3 of Table 2 at the bank level

by bank.do
-this file produces column 4 of Table 2 at the bank level

by bank industry.do
-this file produces column 5 of Table 2 at the bank-industry level

estimation main tables.do
-produces all rest of the regression tables













