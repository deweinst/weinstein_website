clear
set more 1

*need to get export data and collapse by bank and then by bank/industry

use estdata
*drop outliers we identified in firm level data ie top and bottom 1 percentile of dexports
drop if clean1==1
*drop switchers
drop if totswitch==1

*keep balanced sample
keep if month==3
gen x=1
egen sumx=sum(x), by(id)
keep if sumx==14
collapse (sum) exports, by(dbjbankcode_ref year) 


tsset dbjbankcode year
gen dexports=ln(exports)-ln(l.exports)
rename dbjbankcode_ref dbjbankcode
sort dbjbankcode year 
merge dbjbankcode year using foreignbillsdata
tab _merge
keep if _merge==3

drop if year<1987
tab year, gen(yr)

*allow for different bank fe for later years

tab dbjbankcode, gen(dbdum)

*want to keep sample same as with mtb equations
drop if laglvalue==.

*drop first year there is a merger
gen drop=1 if dbjbankcode==80005 & year==1996
replace drop=1 if dbjbankcode==80002 & year==1991
replace drop=1 if dbjbankcode==80006 & year==1992
drop if drop==1

capture log using "by banks.log", replace
areg dexports dbills yr*, absorb(dbjbankcode)  robust 

*********************************************************************


log close
