clear
set mem 700m
set matsize 1000
set more 1 

capture log using nonexporters.log, replace
*this file is exactly the same as the exporters file except that it keeps nonexporters and performs one robustness requested by Helpman
*below, you can choose whether to only keep firms that never export or just the ones that don't export in t and t-1.

use ..\data\dbj1_tantai
drop if year<1984|year>1999

*drop services
drop if ind>20100

*identify exporters
**********************
*note that total sales and exports are defined using the same concept.
*sometimes total sales are zero (in which case so are exports) but gross sales are positive
*we must use total sales to define domestic sales
*but we probably should use gross sales to define value added
rename k0780 sales
rename k2820 gross_sales
*va=gross_sales-material costs-(inventories at beg + inventories at end(-)) - writeoff inventories - overheads +(work-in-process at beginning - work-in-process at end(-))
gen va=gross_sales - k4040 - (k2850 + k2890) - k2910 - k4110 + (k4260 - k4270)
rename k0200 foreign
rename k4040 materials
rename k0440 labor
rename k0900 notesrec
rename k1910 notespay
rename k0790 exports
rename k1280 ca
rename k2290 cl
rename k1880 totassets
rename k2630 totliabilities
rename k2840 costofsales
rename k3890 netincome_pretax
rename k3950 netincome_aftertax
rename k0880 cash
rename k2250 compaper
gen bonds=k2310+k2320+k2330+k1990
rename k0370 shprice_high
rename k0380 shprice_low
gen av_shprice=(shprice_high+shprice_low)/2

drop if exports<0
gen FX=1 if exports>0 & exports~=.
replace FX=0 if FX==.
egen sumFX=sum(FX), by(id)
label var FX "export dummy if exports>0"
label var notesrec "notes receivable"
label var notespay "notes payable"

*dropping duplicate observations - only one exporter
duplicates tag id year, gen(tag)
tab tag
drop if tag>0

*dropping missing sales to avoid having variables in nonselection that are really exporters
drop if sales==.|sales<=0 


*keep exports by destination
*note only those % that add to 100 are likely to be correct. There are 581 firms in 1998 and 578 in 1999. 
rename k0810 ex_na
rename k0820 ex_eu
rename k083 ex_as
rename k0840 ex_me
rename k0850 ex_ot
*fix entry mistake in data
replace ex_eu=ex_eu/10 if id==1206 & year==1998
gen ex_test=ex_na+ex_eu+ex_as+ex_me+ex_ot


*******************************
*prepare variables
**********************************
gen domsales=sales-exports
replace domsales=. if domsales<0

*want to ensure that dexports and ddomsales only occur where reporting month is the same
gen mdate=ym(year, month)
format mdate %tm
tsset id mdate
gen dexports=ln(exports)-ln(l12.exports)
gen pcexports=(exports-l12.exports)/l12.exports
gen ddomsales=ln(domsales)-ln(l12.domsales)
gen dsales=ln(sales)-ln(l12.sales)
gen dexports_domsales=ln(exports/domsales)-ln(l12.exports/l12.domsales)
gen change_exports_domsales=(exports/domsales)-(l12.exports/l12.domsales)
gen change_exports_totsales=(exports/sales)-(l12.exports/l12.sales)
gen dav_shprice=ln(av_shprice)-ln(l12.av_shprice)

gen vaw=va/labor
gen lva=ln(va)
gen lag_lva=l.lva
gen lvaw=ln(vaw)
gen lag_lvaw=l12.lvaw
gen profits= netincome_aftertax/totassets
gen dprofits=(profits-l12.profits)
gen dtotassets=ln(totassets)-ln(l12.totassets)
gen exshare=exports/sales
gen dva=lva-l12.lva
gen dvaw=lvaw-l12.lvaw

tsset id year
gen lagdtotassets=l.dtotassets
gen ldva=l.dva
gen ldvaw=l.dvaw
gen lagdprofits=l.dprofits
gen lagdexports=l.dexports
gen lagdexports_domsales=l.dexports_domsales
gen lagdav_shprice=l.dav_shprice

*heckman selection variable
gen ind3=int(ind/10)
egen max_vaw=max(vaw), by(year ind3)
gen relative_vaw=vaw/max_vaw
gen lagrelative_vaw=l.relative_vaw

drop if year==2000|year==1985|year==1984

*************************
*drop exporters
**********************
*only keep firms that never export at any point in time
egen mFX=mean(FX), by(id)
replace mFX=1 if mFX>0
*drop if mFX==1

*only drop if not exporting that period
drop if FX==1 & l.FX==1


************************************
*clean data
*by dropping top and bottom 1 percentiles of change in exports
*************************************************************


egen s01=pctile(dsales), p(1)
egen s99=pctile(dsales), p(99)
gen clean_s=1 if dsales>s99 & dsales~=.
replace clean_s=1 if dsales<s01 & dsales~=. 


drop k* K*
save nonexporters, replace

*merge on referencebanks and performance measures
sort tsecode year month
merge tsecode year month using referencecitybanks
tab _merge
drop if _merge==2

drop if year<1987

*drop if clean_s==1

egen ind4y=group(ind year)
tab ind4y, gen(idum)
tab year, gen(yr)
tab dbjbankcode_ref, gen(dbdum)

areg dsales lagdvalue_ref dbdum*, absorb(ind4y) cluster(dbjbankcode_ref) robust

areg dsales lagdvalue_ref dbdum* if clean_s~=1, absorb(ind4y) cluster(dbjbankcode_ref) robust
log close



















